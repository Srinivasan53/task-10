from django.contrib import admin
from .models import Company, Role, Employee

admin.site.register(Company)
admin.site.register(Role)
admin.site.register(Employee)
